$a_btn=$("#portfolio").find("div.description > table.table > tbody > tr > td > button[onclick]");
if($a_btn.length==1) {
	$a_btn.click();
}
