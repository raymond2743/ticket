$("body > div.buynow > a button[onclick].red").click();
