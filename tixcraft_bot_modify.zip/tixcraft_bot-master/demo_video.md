# Demo (示範影片)

### 2024-04-11

信用卡活動登錄自動填身份證號碼

https://youtu.be/S_MLG9r0wok

### 刑事局打牛小組逮Max搶票機器人新聞感想
(2024-04-23）

https://youtu.be/m7Z3JKgWrzs

### 2024-04-02
(2024-04-12) cityline 撞牆心得

https://youtu.be/cLFWyI1BLyw

### 2024-04-01
Cityline 自動輸入張數,票價,日期

https://youtu.be/o32TJ6jcS1M

### 2024-03-17
(2024-03-31) 為什麼我太太搶到8張(他就一個帳號+一台破電腦)？

https://youtu.be/d3JxIk4hLsw

### 2024-03-09: 
增加瀏覽器視窗大小的設定值, 方便視窗多開 

https://youtu.be/zPgP43w-ceg

### 2024-03-08 
KKIX 加購粉絲福利

https://youtu.be/Hc2wW_sWiAo

### 2024-03-22
MaxBot 售票系統架構猜測與搶票建議

https://youtu.be/alpy9HX6aRw

### 2024-01-17: 
調整ibon驗證問題的輸入

https://youtu.be/z3mM_Ljui2U

### 2024-01-15: 
MaxBot Plus 1.0.6 擴充功能 for ticktmaster.sg

https://youtu.be/V8S_E7ayAGU

### 2024-01-15: 
增加關鍵字對狀態做開關的切換

https://youtu.be/u3YQCZZu6kE

### 2024-01-10:
MaxBot Plus 擴充功能 刷hkticketing

https://youtu.be/zOzFYJsqWME

### 2024-01-01: 
MaxBot Plus 擴充功能 刷cityline

https://youtu.be/rRl_EETv_b0

### 2023-12-10: 
KKTIX 搶車票

https://youtu.be/csUJ6kRSynY

### 2023-11-04: 
支援新的排序方式：中間選項(center)

ticketmaster 支援區域自動點擊

https://youtu.be/9fqiQHJmIeM

### 2023-10-20: 
FamiTicket 支援新購票頁面

https://youtu.be/EWfdK29P-aw

### 2023-10-10: 
支援設定代理伺服器(Proxy), 還沒支援 account:password 模式.

https://youtu.be/sao9k_PnC0w

### 2023-07-09:
日期關鍵字支援多組與順位

https://youtu.be/IgX4viS1Eq0

### 2023-07-04:
ticketmaster 支援無區域地圖的購票表單

https://youtu.be/Jj2vca2kNZE

### 2023-06-25:
hkticketing 本地端字典檔自動輸入信用卡前6碼

https://youtu.be/BlIRYkd296Y

### 2023-05-27:
ibon 在自動選擇區域時, 支援檢查剩餘張數要大於等於要搶的張數. 

https://youtu.be/gsAXIRI7uj0

### 2023-05-23:
ibon 允許不連續座位

https://youtu.be/A9EU7vgWBiQ

### 2023-05-22:
遠大售票系統

https://youtu.be/mlc7_5O_nwg

### 2023-05-22:
年代售票系統 / 新的關鍵字格式

https://youtu.be/gJo8rGQsyzY

### 2023-05-22:
HKTicketing 快達票

https://youtu.be/U-Rx5RIMFOg

### 2023-04-24:
優化KKTIX 推論驗證問題/示範多開.

https://youtu.be/Wn1qLz-Re8c

### 2023-03-27:
kktix無票時刷新頁面,暫停搶票程式

https://www.youtube.com/watch?v=4trNmMDntwM

### 2023-03-02:
澳門銀河購票無延遲

https://youtu.be/mFxzzWU4ksU

### 2023-02-25:
ibon只搶限定的票價

https://youtu.be/ZtnAh-VY5qs

### 2023-02-25:
透過cookie的ibonqware登入ibon

https://youtu.be/QnaCRQjAlng

### 2023-02-24:
KKTix，多設定檔管理

https://youtu.be/QgLAHkJbhqQ

### 2023-02-22:
拓元，透過 cookie SID登入

https://youtu.be/fkx0HGqTpTg

### 2023-02-19:
拓元，從驗證問題猜測答案

https://youtu.be/5rOi56dNEs8

### 2023-02-16:
拓元，從字典檔輸入驗證答案

https://youtu.be/TuacFXzuvlM

### 2023-02-10:
自動登入/區域關鍵字增加開關

https://youtu.be/Ft2WIWglZ5E

### 2023-02-08:
Edge瀏覽器WebDriver下載與設定

https://youtu.be/TzbBAEVVtoM

### 2023-02-08:
重新支援hkticketing

https://youtu.be/pk-7gIztB2Y

### 2023-02-03:
優化KKTIX 推論驗證問題

https://youtu.be/I4OOTlgpsOA

### 2023-01-29:
支援galaxymacau(澳門銀河)

https://youtu.be/yt7SkRvBujU

### 2023-01-22:
hkticketing(快達票)

https://youtu.be/pZJlcMjayco

### 2023-01-14:
優化KKTIX "演出日期"的驗證問題

https://youtu.be/ChmGZMaV2w8

### 2023-01-14:
indievox 猜測驗證碼 / 視窗多開

https://youtu.be/O84H1wNO2_w

### 2023-01-11:
tixcraft 自動輸入驗證碼

https://youtu.be/t1k0CvmBNhQ (macOS)

https://youtu.be/6JdEdcW8LtY (Windows)

### 2023-01-07:
輸入驗證問題答案為"同意"

https://youtu.be/UgemzrsCC-M

### 2023-01-05:
不等 cityline 的 10秒，直接重導網址

https://youtu.be/wGU4GJJ-ufw

### 2023-01-02:
KKITX自動猜測驗證問題

https://youtu.be/7CtSVBGwx9I (macOS)

https://youtu.be/BcyfkXF2AJU (Windows)

### 2023-01-02:
支援 ibon 售票系統

https://youtu.be/VaYc5GKk1Rk

### 2023-01-01:
支援新版本的 cityline

https://youtu.be/R5LY7pJgAzI (macOS)

https://youtu.be/2UNaAEjysvk (Windows)

### 2023-01-01:
支援新版本的 urbtix

https://youtu.be/_6jxqVC39x8 (macOS)

https://youtu.be/PWKBZ8aG9Rg (Windows)

### 2022-11-24:
KKTix 支援避開「剩餘 1」的區域的功能。增加關鍵字#2 的欄位。

https://youtu.be/nupJlwRNOIA

### 2022-11-18:
增加 adblock plus 的功能。輸入驗證碼時，會播放音效，在清票時很有幫功，不需要一直緊盯著螢幕。

https://youtu.be/Atujl8MPHQI

### 2022-11-06:
優化kktix/拓元的關鍵字比對，修改為不區分逗號、空格與大小寫。

https://youtu.be/v9mI02kVaNw

### 2022-10-22:
優化kktix/拓元的價格的關鍵字比對。

https://youtu.be/NZzQcDQkrNI

### 2022-10-21:
針對kktix 活動增加第二個關鍵字欄位。

https://youtu.be/x-OdqvUupiA

### 2022-01-26:
FamiTicket

https://youtu.be/ZV-G91FHVik
